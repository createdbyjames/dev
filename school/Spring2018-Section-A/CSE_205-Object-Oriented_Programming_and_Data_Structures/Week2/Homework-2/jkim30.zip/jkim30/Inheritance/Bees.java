public class Bees extends Insect {

    @Override
    public void makeNoise() {
        System.out.println("Buzzzz");
    }
}
