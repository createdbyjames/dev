public class Frogs extends Mammal {

    @Override
    public void makeNoise() {
        System.out.println("Ribbet");
    }
}
