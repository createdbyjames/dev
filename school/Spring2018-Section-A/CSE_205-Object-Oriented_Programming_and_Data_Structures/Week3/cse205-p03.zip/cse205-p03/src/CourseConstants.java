//***************************************************************************************************************************
// CLASS: CourseConstants
//
// AUTHOR
// Your author information
//***************************************************************************************************************************
package p03;

public class CourseConstants {

    public static final int NUM_EXAMS     = 2;
    public static final int NUM_HOMEWORKS = 4;

}
